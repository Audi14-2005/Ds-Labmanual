// screens/DashboardScreen.js
import React from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Icon from 'react-native-vector-icons/MaterialIcons';

// Screens (to be defined later)
const HarvestScreen = () => <View style={styles.screen}><Text>Harvest Screen</Text></View>;
const CropDiseaseScreen = () => <View style={styles.screen}><Text>Crop Disease Screen</Text></View>;
const CropStoreScreen = () => <View style={styles.screen}><Text>Crop Store Screen</Text></View>;

// Create a bottom tab navigator
const Tab = createBottomTabNavigator();

const DashboardScreen = () => {
  return (
    <View style={styles.container}>
      {/* Account Details Section */}
      <View style={styles.accountDetails}>
        <Image
          source={{ uri: 'https://via.placeholder.com/100' }} // Replace with user's image URL
          style={styles.profileImage}
        />
        <View style={styles.details}>
          <Text style={styles.name}>John Doe</Text>
          <Text style={styles.email}>johndoe@email.com</Text>
          <Text style={styles.phone}>+91-1234567890</Text>
        </View>
      </View>

      {/* Bottom Navigation */}
      <Tab.Navigator
        screenOptions={{
          tabBarActiveTintColor: '#fff',
          tabBarStyle: { backgroundColor: '#2e7d32' }, // Green background for the tab bar
        }}
      >
        <Tab.Screen
          name="Harvest"
          component={HarvestScreen}
          options={{
            tabBarIcon: ({ color }) => <Icon name="agriculture" size={24} color={color} />,
          }}
        />
        <Tab.Screen
          name="Crop Disease"
          component={CropDiseaseScreen}
          options={{
            tabBarIcon: ({ color }) => <Icon name="healing" size={24} color={color} />,
          }}
        />
        <Tab.Screen
          name="Crop Store"
          component={CropStoreScreen}
          options={{
            tabBarIcon: ({ color }) => <Icon name="store" size={24} color={color} />,
          }}
        />
      </Tab.Navigator>
    </View>
  );
};

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#e8f5e9', // Light green background for the dashboard
  },
  accountDetails: {
    flexDirection: 'row',
    padding: 20,
    backgroundColor: '#2e7d32', // Dark green background for the header
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    alignItems: 'center',
  },
  profileImage: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginRight: 20,
  },
  details: {
    justifyContent: 'center',
  },
  name: {
    fontSize: 20,
    color: '#fff',
    fontWeight: 'bold',
  },
  email: {
    fontSize: 14,
    color: '#fff',
    marginTop: 5,
  },
  phone: {
    fontSize: 14,
    color: '#fff',
    marginTop: 5,
  },
  screen: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default DashboardScreen;
